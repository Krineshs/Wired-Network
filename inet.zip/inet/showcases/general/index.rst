Generic
=======

These showcases demonstrate various aspects of performing network
simulations with INET.

.. toctree::
   :maxdepth: 1

   pcaprecording/doc/index
   diffserv/doc/index
.. mobility/doc/index
.. dynamic/doc/index
